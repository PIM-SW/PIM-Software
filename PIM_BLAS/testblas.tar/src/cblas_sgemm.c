#include "pim_avail_op.h"
#include "cblas.h"

void cblas_sgemm(const enum CBLAS_ORDER Order, const enum CBLAS_TRANSPOSE TransA,
	const enum CBLAS_TRANSPOSE TransB, const int M, const int N,
	const int K, const float alpha, float* A,
	const int lda, float* B, const int ldb,
	const float beta, float* C, const int ldc) {
	float(*array2A)[16] = (float(*)[16]) A;
	float(*array2B)[16] = (float(*)[16]) B;
	float OrderChangeA[16][16], OrderChangeB[16][16],
		transposeA[16][16], transposeB[16][16];
	if (Order == 102) {
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				OrderChangeA[i][j] = array2A[j][i];
				OrderChangeB[i][j] = array2B[j][i];
			}
		}
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				A[i * N + j] = OrderChangeA[i][j];
				B[i * N + j] = OrderChangeB[i][j];
			}
		}
	}
	if (TransA == 112 || TransA == 113) {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				transposeA[i][j] = array2A[j][i];
			}
		}
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				A[i * N + j] = transposeA[i][j];
			}
		}
	}
	if (TransB == 111 || TransB == 114) {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				transposeB[i][j] = array2B[j][i];
			}
		}
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				B[i * N + j] = transposeB[i][j];
			}
		}
	}
	float tempAB[256];
	for (int i = 0; i < ldb; i++) {
		for (int j = 0; j < lda; j++) {
			tempAB[lda * i + j] = MAC_16(A, B);
			B = B + lda;
		}
		B = B - lda * ldb;
		A = A + lda;
	}
	for (int i = 0; i < ldb; i++) {
		for (int j = 0; j < lda; j++) {
			B[lda * i + j] = tempAB[lda * i + j];
		}
	}
	for (int i = 0; i < lda; i++) {
		SIMD_SCAL_MUL_16(alpha, B);
		B = B + ldb;
	}
	B = B - lda * ldb;
	for (int i = 0; i < ldb; i++) {
		SIMD_SCAL_MUL_16(beta, C);
		C = C + ldc;
	}
	C = C - ldb * ldc;
	for (int i = 0; i < ldb; i++) {
		SIMD_ADD_16(B, C);
		B = B + ldb;
		C = C + ldc;
	}
	printf("escal cblas_sgemm enabled!! \n");
}