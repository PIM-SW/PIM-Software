#include "pim_avail_op.h"
#include "cblas.h"

void cblas_sgemv(const enum CBLAS_ORDER Order,
	const enum CBLAS_TRANSPOSE TransA, const int M, const int N,
	const float alpha, float* A, const int lda,
	float* X, const int incX, const float beta,
	float* Y, const int incY) {
	float(*array2)[16] = (float(*)[16]) A;
	float OrderChange[16][16], transpose[16][16] = { 0 };
	if (Order == 102) {
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				OrderChange[i][j] = array2[j][i];
			}
		}
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				A[i * N + j] = OrderChange[i][j];
			}
		}
	}
	if (TransA == 112 || TransA == 113) {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				transpose[i][j] = array2[j][i];
			}
		}
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				A[i * N + j] = transpose[i][j];
			}
		}
	}
	float tempAX[16] = { 0 };
	float tempX[16] = { 0 };
	float tempY[16] = { 0 };
	if (incX == 1) {
		for (int i = 0; i < lda; i++) {
			tempAX[i] = MAC_16(A, X);
			A = A + lda;
		}
	}
	else if (incX > 1) {
		for (int i = 0; i < lda; i++) {
			tempX[i] = X[(i)*incX];
		}
		for (int i = 0; i < lda; i++) {
			tempAX[i] = MAC_16(A, tempX);
			A = A + lda;
		}
	}
	else {
		assert(0);
	}
	SIMD_SCAL_MUL_16(alpha, tempAX);
	if (incY == 1) {
		SIMD_SCAL_MUL_16(beta, Y);
	}
	else if (incY > 1) {
		for (int i = 0; i < lda; i++) {
			tempY[i] = Y[(i)*incY];
		}
		SIMD_SCAL_MUL_16(beta, tempY);
	}
	else {
		assert(0);
	}
	SIMD_ADD_16(tempAX, tempY);

	for (int i = 0; i < lda; i++) {
		Y[i] = tempY[i];
	}
	printf("escal cblas_sgemv enabled!! \n");
}