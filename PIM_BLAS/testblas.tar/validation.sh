make clean
make
rm escal_out.txt original_out.txt
./escal_cblas > escal_out.txt &&
./original_cblas > original_out.txt &&
diff escal_out.txt original_out.txt